/*********************************************************************************/
/* Author    : Mohamed Abd El-Naby                                               */
/* Version   : V01                                                               */
/* Date      : 11 September 2020                                                   */
/*********************************************************************************/
#ifndef STD_TYPES_H
#define STD_TYPES_H

	typedef unsigned char 		u8;
	typedef unsigned int  	 	u16;
	typedef unsigned long int 	u32;




#endif
