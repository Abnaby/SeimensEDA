/*********************************************************************************/
/* Author    : Mohamed Abd El-Naby                                               */
/* Version   : V01                                                               */
/* Date      : 11 September 2020                                                   */
/*********************************************************************************/
#include "STD_TYPES.h"
#include "BIT_MATH.h"

#include "CAN_interface.h"
int main(void)
{
	/*	  peripheral clock must be enabled using the RCGC0 register 	*/
	/*	  the clock to the appropriate GPIO module must be enabled via the RCGC2	*/
	/*	  Set the GPIO AFSEL bits for the appropriate pins	*/
	/*	  Set the GPIO AFSEL bits for the appropriate pins	*/
	
	while(1)
	{
	}
	//return 0; 
}
